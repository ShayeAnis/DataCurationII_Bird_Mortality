# Heavy migration traffic and bad weather are a dangerous combination: bird collisions in New York City

The collisions_weather_migration_spring_fall_dataset.csv file contains all of the variables included in our final spring and fall generalized linear mixed effects models of the effects of weather and migration traffic on bird collisions with buildings in New York, NY, 2017-2021.

Note that the buildings that were monitored for collisions were known or expected to be high collision hazards and were specifically chosen to increase the likelihood of detecting collision events under a range of weather conditions. Thus, this dataset's sample is not necessarily representative of citywide collision rates. Also note that the KOKX radar station, where we obtained the data used for our migration traffic variable, is located just under 100 km from NYC. As such, this metric was not a direct calculation of the number of migrants in NYC and was treated as a regional measure of migration activity in the NYC area.  

## Description of the variable columns:

*   **date -** the date from when the collision data was collected. Nocturnal weather and migration data are averaged measurements taken from dusk the night prior to dawn the morning of.
*   **year -** the year.
*   **yday -** the day of year. Also known as the Julian date.
*   **building -** the letter code we assigned to the building surveyed. For the corresponding building addresses, please refer to Table S2 in the supplementary materials for the associated manuscript.
    *   Data source: NYC Audubon's Project Safe Flight.
*   **volunteer -** the volunteer or pair of volunteers who conducted the survey.
    *   Data source: NYC Audubon's Project Safe Flight.
*   **count -** collisions counts of individual birds per building per day.
    *   Data source: NYC Audubon's Project Safe Flight.
*   **uwind -** east–west wind component (speed and direction) in ms-1 measured at 9 m above ground level. Positive values indicate winds coming from the west. Also known as zonal wind.
    *   Data source: LaGuardia Airport weather station.
*   **vwind -** north–south wind component (speed and direction) in ms-1 measured at 9 m above ground level. Positive values indicate winds coming from the south. Also known as meridional wind.
    *   Data source: LaGuardia Airport weather station.
*   **ceiling_height -** the height in meters above ground level of the lowest cloud or obscuring phenomena layer aloft with 5/8 or more summation total sky cover, which may be predominately opaque, or the vertical visibility into a surface-based obstruction.
    *   Data source: LaGuardia Airport weather station.
*   **visibility_distance -** the horizontal distance in meters at which an object can be seen and identified.
    *   Data source: LaGuardia Airport weather station.
*   **visibility** - a categorical variable where “low” indicates a visibility distance <10 km, “medium” indicates a visibility distance between 10 to 16 km, and “high” indicates a visibility distance >16 km.
    *   Created using the visibility distance data obtained from the LaGuardia Airport weather station.
*   **temperature -** the temperature of the air in degrees Celsius (˚C) measured at 9 m above ground level.
    *   Data source: LaGuardia Airport weather station.
*   **amt -** average migration traffic. The average number of individual birds passing by the radar per night measured as number of individuals per kilometer per hour.
    *   Data source: KOKX radar.

Day of year, zonal wind component, meridional wind component, cloud ceiling height, temperature, and average migration traffic variables were standardized to have a mean of 0 and a variance of 1 to aid model convergence. Column names for the standardized variables start with "scaled_".