# Title of dataset: Bird-building collisions increase with weather conditions that favor nocturnal migration and with inclement and changing weather

This Dryad data upload contains 4 files related to Lao et al. 2022: "Bird-building collisions increase with weather conditions that favor nocturnal migration and with inclement and changing weather."

1) The input file used for the spring entire night analysis of weather effects on bird-building collisions
2) The input file used for the spring within-night analysis of weather effects on bird-building collisions
3) The input file used for the fall entire night analysis of weather effects on bird-building collisions
4) The input file used for the fall within-night analysis of weather effects on bird-building collisions


## Definitions for data columns found in these files are included below:

SpCount: number of bird collisions found during morning surveys in spring (15 March- 31 May)

FaCount: number of bird collisions found during morning surveys in fall (15 August- 31October)

Date: date of observation


The following column names describe the weather variables evaluated. The data originates from NOAA’s Local Climatological Data (LCD) Dataset from the Minneapolis-Saint Paul Airport weather station. 
For entire night data, column names of each variable are listed in this format: variable_timelag
For within-night data, column names for each variable are listed in this format: Variable_TimeOfNight_TimeLag

CloudConditions: Average cloud conditions ranging on a scale of 0-8, where 0 represents clear sky and 8 represents overcast sky

VisibilityKm: Average visibility in kilometers, defined as the horizontal distance at which an object can be seen and identified with the unaided eye

TempC: Average dry-bulb temperature in degrees Celsius

CloudBaseM: Average minimum cloud base height in meters, estimated by subtracting dew point from temperature and dividing by 400

PressureMm: Average atmospheric pressure observed at the station given in millimeters of Mercury (Hg)

PrecipCm: Average amount of precipitation in centimeters

WindSpeedKPH: Average wind speed in kilometers per hour

N: Binary variable for presence/absence of northerly winds. Northerly winds were considered present if at least one hourly reading included N, NE, NW, NNE, or NNW wind

S: Binary variable for presence/absence of southerly winds. Southerly winds were considered present if at least one hourly reading included S, SE, SW, SSE, or SSW wind

TStorm: Binary variable for presence/absence of thunderstorms. Thunderstorms were considered present if at least one hourly reading included the occurrence of thunderstorms

Precip: Binary variable for presence/absence of precipitation. Precipitation was considered present if at lest one hourly reading included rain, snow, or drizzle


Time of Night definitions:

SS: within one hour before and after sunset

N1: during the first half of the night (1 hour after sunset to the nightly midpoint between sunset and sunrise)

N2: during the second half of the night (nightly midpoint to 1 hour before sunrise)

SR: within one hour before and after sunrise


Time Lag definitions:

0: 0 time lag (weather conditions the night immediately preceding morning surveys

1: 1-night time lag (weather conditions 2 nights before morning surveys)

2: 2-night time lag (weather conditions 3 nights before morning surveys)